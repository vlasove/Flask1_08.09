from app.models.user import User
from werkzeug.security import safe_str_cmp


def authenticate(username, password):
    # Нужно научиться доставать пользователя из БД по его username +
    
    user = User.search_username(username)
    print(user)
    if user  and safe_str_cmp(user.password , password):
        print("Yes, authenticates")
        return user 


def identity(data):
    uid = data['identity']
    # Нужно научиться доставать пользователя из БД по его id +
    return User.search_id(uid)