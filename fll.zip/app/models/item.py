from app import db

class Item(db.Model):
    __tablename__ = "items"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), index=True, unique=True)
    price = db.Column(db.Float)
    amount = db.Column(db.Integer)

    def __init__(self, name, price, amount):
        self.name = name
        self.price = price
        self.amount = amount

    def json(self):
        return {"name" : self.name, "price" : self.price, "amount" : self.amount}

    @classmethod
    def search_name(cls, name):
        return cls.query.filter_by(name=name).first()

    @classmethod
    def get_all(cls):
        return cls.query.all()

    def insert(self):
        db.session.add(self)
        db.session.commit()

    def update(self):
        db.session.add(self)
        db.session.commit()

    def delete(self):
        db.session.delete(self)
        db.session.commit()

    def __repr__(self):
        return '<Item {}>'.format(self.name)    