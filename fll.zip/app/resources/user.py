from flask_restful import Resource, reqparse
from app.models.user import User



# Пользовательский ресурс
class UserResource(Resource):
    
    parser = reqparse.RequestParser()
    parser.add_argument("username", type=str, required=True, help="Username field required!")
    parser.add_argument("password", type=str, required=True, help="Password field required!")
    parser.add_argument("email", type=str, required=True, help="This field can not be blank!")

    def post(self):
        request_body = UserResource.parser.parse_args()

        if User.search_username(request_body["username"]):
            return {"Error" : "User with that username already exists!"}, 400

        user = User( request_body["username"], request_body["password"], request_body["email"])
        user.insert()

        return {"Message" : "User created"}, 201