from flask import Flask , request
from flask_restful import Resource, Api , reqparse
from flask_jwt import JWT, jwt_required, current_identity
from app.configs import Config
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate


app = Flask(__name__)
app.config.from_object(Config)


db = SQLAlchemy(app)
migrate = Migrate(app, db)

from app.models.user import User
from app.models.item import Item
from app.resources.item import ItemResource, ItemCollectionResource
from app.resources.user import UserResource
from app.utils.secure import authenticate, identity


api = Api(app, prefix="/api/v1")
jwt = JWT(app, authentication_handler=authenticate, identity_handler=identity)


api.add_resource(ItemResource, "/item/<string:name>")
api.add_resource(ItemCollectionResource, "/items")
api.add_resource(UserResource, "/register")




