from app import app, db
from app.models.user import User
from app.models.item import Item

@app.shell_context_processor
def make_shell_context():
    return {"app":app, "db" : db, "User" : User, "Item" : Item}

if __name__ == "__main__":
    app.run()